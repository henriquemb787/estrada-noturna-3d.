const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const www = path.join(root, 'www');
const threeSource = path.join(root, 'node_modules', 'three', 'build', 'three.min.js');
const vendorDir = path.join(www, 'vendor');

if (!fs.existsSync(path.join(www, 'index.html'))) {
  throw new Error('Não encontrei www/index.html');
}
if (!fs.existsSync(threeSource)) {
  throw new Error('Three.js não foi instalado. Execute npm install primeiro.');
}

fs.mkdirSync(vendorDir, { recursive: true });
fs.copyFileSync(threeSource, path.join(vendorDir, 'three.min.js'));
console.log('Build preparado: Three.js copiado para www/vendor/.');
