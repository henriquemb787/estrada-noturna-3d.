@echo off
chcp 65001 >nul
echo Instalando dependencias...
call npm install
if errorlevel 1 goto erro
echo Preparando os arquivos do jogo...
call npm run build
if errorlevel 1 goto erro
echo Criando plataforma Android...
call npm run android:add
if errorlevel 1 goto erro
echo Sincronizando projeto Android...
call npm run android:sync
if errorlevel 1 goto erro
echo Abrindo Android Studio...
call npm run android:open
goto fim
:erro
echo.
echo Ocorreu um erro. Confira a mensagem acima.
pause
:fim
